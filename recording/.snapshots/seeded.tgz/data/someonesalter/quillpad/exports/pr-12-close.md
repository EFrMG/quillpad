Thanks for this. The same change, recommending `pipx` and keeping `pip` as the alternative, is already on `main`, so there is nothing left for this pull request to add and we are closing it.
