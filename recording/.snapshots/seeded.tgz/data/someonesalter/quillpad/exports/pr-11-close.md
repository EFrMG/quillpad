Thank you for the work on this, and for the search numbers.

We are going to close this pull request rather than review it further. quillpad's main promise is that notes are plain Markdown files that stay readable and editable without the tool. With this change, `list` and `search` read only the database, so a note edited by hand is no longer picked up.

If slow search is the problem to solve, #18 keeps plain files and adds an index. A comparison of the two on a large notes directory would be very welcome there.
