# Maintainer brief

Two batches screened, 16 items. Four things need you.

## Decide

1. **Tags with spaces.** [issue #2](https://github.com/someonesalter/quillpad/issues/2) has two fixes, [PR #3](https://github.com/someonesalter/quillpad/pull/3) and [PR #4](https://github.com/someonesalter/quillpad/pull/4). They cannot both land. The group brief recommends #4.
2. **SQLite storage.** [PR #11](https://github.com/someonesalter/quillpad/pull/11) trades plain files for fast search. The item brief recommends closing it and pointing to [PR #18](https://github.com/someonesalter/quillpad/pull/18).
3. **Sync.** [issue #22](https://github.com/someonesalter/quillpad/issues/22) asks for built-in sync, the first network feature. Flagged for Pending review.

## Merge

[PR #8](https://github.com/someonesalter/quillpad/pull/8), [PR #9](https://github.com/someonesalter/quillpad/pull/9) and [PR #25](https://github.com/someonesalter/quillpad/pull/25) are small, tested and reviewed.

```sh
gh pr merge 8 --squash
gh pr merge 9 --squash
gh pr merge 25 --squash
```

## Close

[PR #12](https://github.com/someonesalter/quillpad/pull/12) is already on `main`. [issue #14](https://github.com/someonesalter/quillpad/issues/14) duplicates [issue #1](https://github.com/someonesalter/quillpad/issues/1).
